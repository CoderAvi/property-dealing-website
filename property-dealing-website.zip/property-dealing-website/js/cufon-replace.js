Cufon.replace('#menu a, .nivo-caption strong, h2, h3, h4, .date, .call', { fontFamily: 'Didact Gothic', hover:true });

